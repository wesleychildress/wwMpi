/* This is a generated file, don't edit */

#define NUM_APPLETS 354

const char applet_names[] ALIGN1 = ""
"[" "\0"
"[[" "\0"
"acpid" "\0"
"add-shell" "\0"
"addgroup" "\0"
"adduser" "\0"
"adjtimex" "\0"
"arp" "\0"
"arping" "\0"
"ash" "\0"
"awk" "\0"
"base64" "\0"
"basename" "\0"
"beep" "\0"
"blkid" "\0"
"blockdev" "\0"
"bootchartd" "\0"
"brctl" "\0"
"bunzip2" "\0"
"bzcat" "\0"
"bzip2" "\0"
"cal" "\0"
"cat" "\0"
"catv" "\0"
"chat" "\0"
"chattr" "\0"
"chcon" "\0"
"chgrp" "\0"
"chmod" "\0"
"chown" "\0"
"chpasswd" "\0"
"chpst" "\0"
"chroot" "\0"
"chrt" "\0"
"chvt" "\0"
"cksum" "\0"
"clear" "\0"
"cmp" "\0"
"comm" "\0"
"cp" "\0"
"cpio" "\0"
"crond" "\0"
"crontab" "\0"
"cryptpw" "\0"
"cttyhack" "\0"
"cut" "\0"
"date" "\0"
"dc" "\0"
"dd" "\0"
"deallocvt" "\0"
"delgroup" "\0"
"deluser" "\0"
"depmod" "\0"
"devmem" "\0"
"df" "\0"
"dhcprelay" "\0"
"diff" "\0"
"dirname" "\0"
"dmesg" "\0"
"dnsd" "\0"
"dnsdomainname" "\0"
"dos2unix" "\0"
"du" "\0"
"dumpkmap" "\0"
"dumpleases" "\0"
"echo" "\0"
"ed" "\0"
"egrep" "\0"
"eject" "\0"
"env" "\0"
"envdir" "\0"
"envuidgid" "\0"
"ether-wake" "\0"
"expand" "\0"
"expr" "\0"
"fakeidentd" "\0"
"false" "\0"
"fbset" "\0"
"fbsplash" "\0"
"fdflush" "\0"
"fdformat" "\0"
"fdisk" "\0"
"fgconsole" "\0"
"fgrep" "\0"
"find" "\0"
"findfs" "\0"
"flock" "\0"
"fold" "\0"
"free" "\0"
"freeramdisk" "\0"
"fsck" "\0"
"fsck.minix" "\0"
"fsync" "\0"
"ftpd" "\0"
"ftpget" "\0"
"ftpput" "\0"
"fuser" "\0"
"getenforce" "\0"
"getopt" "\0"
"getsebool" "\0"
"getty" "\0"
"grep" "\0"
"groups" "\0"
"gunzip" "\0"
"gzip" "\0"
"halt" "\0"
"hd" "\0"
"hdparm" "\0"
"head" "\0"
"hexdump" "\0"
"hostid" "\0"
"hostname" "\0"
"httpd" "\0"
"hush" "\0"
"hwclock" "\0"
"id" "\0"
"ifconfig" "\0"
"ifdown" "\0"
"ifenslave" "\0"
"ifplugd" "\0"
"ifup" "\0"
"inetd" "\0"
"init" "\0"
"insmod" "\0"
"install" "\0"
"ionice" "\0"
"iostat" "\0"
"ip" "\0"
"ipaddr" "\0"
"ipcalc" "\0"
"ipcrm" "\0"
"ipcs" "\0"
"iplink" "\0"
"iproute" "\0"
"iprule" "\0"
"iptunnel" "\0"
"kbd_mode" "\0"
"kill" "\0"
"killall" "\0"
"killall5" "\0"
"klogd" "\0"
"last" "\0"
"less" "\0"
"linux32" "\0"
"linux64" "\0"
"linuxrc" "\0"
"ln" "\0"
"load_policy" "\0"
"loadfont" "\0"
"loadkmap" "\0"
"logger" "\0"
"login" "\0"
"logname" "\0"
"logread" "\0"
"losetup" "\0"
"lpd" "\0"
"lpq" "\0"
"lpr" "\0"
"ls" "\0"
"lsattr" "\0"
"lsmod" "\0"
"lspci" "\0"
"lsusb" "\0"
"lzcat" "\0"
"lzma" "\0"
"lzop" "\0"
"lzopcat" "\0"
"makedevs" "\0"
"makemime" "\0"
"man" "\0"
"matchpathcon" "\0"
"md5sum" "\0"
"mdev" "\0"
"mesg" "\0"
"microcom" "\0"
"mkdir" "\0"
"mkdosfs" "\0"
"mke2fs" "\0"
"mkfifo" "\0"
"mkfs.ext2" "\0"
"mkfs.minix" "\0"
"mkfs.vfat" "\0"
"mknod" "\0"
"mkpasswd" "\0"
"mkswap" "\0"
"mktemp" "\0"
"modinfo" "\0"
"modprobe" "\0"
"more" "\0"
"mount" "\0"
"mountpoint" "\0"
"mpstat" "\0"
"mt" "\0"
"mv" "\0"
"nameif" "\0"
"nbd-client" "\0"
"nc" "\0"
"netstat" "\0"
"nice" "\0"
"nmeter" "\0"
"nohup" "\0"
"nslookup" "\0"
"ntpd" "\0"
"od" "\0"
"openvt" "\0"
"passwd" "\0"
"patch" "\0"
"pgrep" "\0"
"pidof" "\0"
"ping" "\0"
"ping6" "\0"
"pipe_progress" "\0"
"pivot_root" "\0"
"pkill" "\0"
"pmap" "\0"
"popmaildir" "\0"
"poweroff" "\0"
"powertop" "\0"
"printenv" "\0"
"printf" "\0"
"ps" "\0"
"pscan" "\0"
"pstree" "\0"
"pwd" "\0"
"pwdx" "\0"
"raidautorun" "\0"
"rdate" "\0"
"rdev" "\0"
"readahead" "\0"
"readlink" "\0"
"readprofile" "\0"
"realpath" "\0"
"reboot" "\0"
"reformime" "\0"
"remove-shell" "\0"
"renice" "\0"
"reset" "\0"
"resize" "\0"
"restorecon" "\0"
"rev" "\0"
"rm" "\0"
"rmdir" "\0"
"rmmod" "\0"
"route" "\0"
"rpm" "\0"
"rpm2cpio" "\0"
"rtcwake" "\0"
"run-parts" "\0"
"runcon" "\0"
"runlevel" "\0"
"runsv" "\0"
"runsvdir" "\0"
"rx" "\0"
"script" "\0"
"scriptreplay" "\0"
"sed" "\0"
"selinuxenabled" "\0"
"sendmail" "\0"
"seq" "\0"
"sestatus" "\0"
"setarch" "\0"
"setconsole" "\0"
"setenforce" "\0"
"setfiles" "\0"
"setfont" "\0"
"setkeycodes" "\0"
"setlogcons" "\0"
"setsebool" "\0"
"setserial" "\0"
"setsid" "\0"
"setuidgid" "\0"
"sh" "\0"
"sha1sum" "\0"
"sha256sum" "\0"
"sha512sum" "\0"
"showkey" "\0"
"slattach" "\0"
"sleep" "\0"
"smemcap" "\0"
"softlimit" "\0"
"sort" "\0"
"split" "\0"
"start-stop-daemon" "\0"
"stat" "\0"
"strings" "\0"
"stty" "\0"
"su" "\0"
"sulogin" "\0"
"sum" "\0"
"sv" "\0"
"svlogd" "\0"
"swapoff" "\0"
"swapon" "\0"
"switch_root" "\0"
"sync" "\0"
"sysctl" "\0"
"syslogd" "\0"
"tac" "\0"
"tail" "\0"
"tar" "\0"
"tcpsvd" "\0"
"tee" "\0"
"telnet" "\0"
"telnetd" "\0"
"test" "\0"
"tftp" "\0"
"tftpd" "\0"
"time" "\0"
"timeout" "\0"
"top" "\0"
"touch" "\0"
"tr" "\0"
"traceroute" "\0"
"traceroute6" "\0"
"true" "\0"
"tty" "\0"
"ttysize" "\0"
"tunctl" "\0"
"udhcpc" "\0"
"udhcpd" "\0"
"udpsvd" "\0"
"umount" "\0"
"uname" "\0"
"unexpand" "\0"
"uniq" "\0"
"unix2dos" "\0"
"unlzma" "\0"
"unlzop" "\0"
"unxz" "\0"
"unzip" "\0"
"uptime" "\0"
"users" "\0"
"usleep" "\0"
"uudecode" "\0"
"uuencode" "\0"
"vconfig" "\0"
"vi" "\0"
"vlock" "\0"
"volname" "\0"
"wall" "\0"
"watch" "\0"
"watchdog" "\0"
"wc" "\0"
"wget" "\0"
"which" "\0"
"who" "\0"
"whoami" "\0"
"whois" "\0"
"xargs" "\0"
"xz" "\0"
"xzcat" "\0"
"yes" "\0"
"zcat" "\0"
"zcip" "\0"
;

#ifndef SKIP_applet_main
int (*const applet_main[])(int argc, char **argv) = {
test_main,
test_main,
acpid_main,
add_remove_shell_main,
addgroup_main,
adduser_main,
adjtimex_main,
arp_main,
arping_main,
ash_main,
awk_main,
base64_main,
basename_main,
beep_main,
blkid_main,
blockdev_main,
bootchartd_main,
brctl_main,
bunzip2_main,
bunzip2_main,
bzip2_main,
cal_main,
cat_main,
catv_main,
chat_main,
chattr_main,
chcon_main,
chgrp_main,
chmod_main,
chown_main,
chpasswd_main,
chpst_main,
chroot_main,
chrt_main,
chvt_main,
cksum_main,
clear_main,
cmp_main,
comm_main,
cp_main,
cpio_main,
crond_main,
crontab_main,
cryptpw_main,
cttyhack_main,
cut_main,
date_main,
dc_main,
dd_main,
deallocvt_main,
deluser_main,
deluser_main,
modprobe_main,
devmem_main,
df_main,
dhcprelay_main,
diff_main,
dirname_main,
dmesg_main,
dnsd_main,
hostname_main,
dos2unix_main,
du_main,
dumpkmap_main,
dumpleases_main,
echo_main,
ed_main,
grep_main,
eject_main,
env_main,
chpst_main,
chpst_main,
ether_wake_main,
expand_main,
expr_main,
fakeidentd_main,
false_main,
fbset_main,
fbsplash_main,
freeramdisk_main,
fdformat_main,
fdisk_main,
fgconsole_main,
grep_main,
find_main,
findfs_main,
flock_main,
fold_main,
free_main,
freeramdisk_main,
fsck_main,
fsck_minix_main,
fsync_main,
ftpd_main,
ftpgetput_main,
ftpgetput_main,
fuser_main,
getenforce_main,
getopt_main,
getsebool_main,
getty_main,
grep_main,
id_main,
gunzip_main,
gzip_main,
halt_main,
hexdump_main,
hdparm_main,
head_main,
hexdump_main,
hostid_main,
hostname_main,
httpd_main,
hush_main,
hwclock_main,
id_main,
ifconfig_main,
ifupdown_main,
ifenslave_main,
ifplugd_main,
ifupdown_main,
inetd_main,
init_main,
modprobe_main,
install_main,
ionice_main,
iostat_main,
ip_main,
ipaddr_main,
ipcalc_main,
ipcrm_main,
ipcs_main,
iplink_main,
iproute_main,
iprule_main,
iptunnel_main,
kbd_mode_main,
kill_main,
kill_main,
kill_main,
klogd_main,
last_main,
less_main,
setarch_main,
setarch_main,
init_main,
ln_main,
load_policy_main,
loadfont_main,
loadkmap_main,
logger_main,
login_main,
logname_main,
logread_main,
losetup_main,
lpd_main,
lpqr_main,
lpqr_main,
ls_main,
lsattr_main,
modprobe_main,
lspci_main,
lsusb_main,
unlzma_main,
unlzma_main,
lzop_main,
lzop_main,
makedevs_main,
makemime_main,
man_main,
matchpathcon_main,
md5_sha1_sum_main,
mdev_main,
mesg_main,
microcom_main,
mkdir_main,
mkfs_vfat_main,
mkfs_ext2_main,
mkfifo_main,
mkfs_ext2_main,
mkfs_minix_main,
mkfs_vfat_main,
mknod_main,
cryptpw_main,
mkswap_main,
mktemp_main,
modinfo_main,
modprobe_main,
more_main,
mount_main,
mountpoint_main,
mpstat_main,
mt_main,
mv_main,
nameif_main,
nbdclient_main,
nc_main,
netstat_main,
nice_main,
nmeter_main,
nohup_main,
nslookup_main,
ntpd_main,
od_main,
openvt_main,
passwd_main,
patch_main,
pgrep_main,
pidof_main,
ping_main,
ping6_main,
pipe_progress_main,
pivot_root_main,
pgrep_main,
pmap_main,
popmaildir_main,
halt_main,
powertop_main,
printenv_main,
printf_main,
ps_main,
pscan_main,
pstree_main,
pwd_main,
pwdx_main,
raidautorun_main,
rdate_main,
rdev_main,
readahead_main,
readlink_main,
readprofile_main,
realpath_main,
halt_main,
reformime_main,
add_remove_shell_main,
renice_main,
reset_main,
resize_main,
setfiles_main,
rev_main,
rm_main,
rmdir_main,
modprobe_main,
route_main,
rpm_main,
rpm2cpio_main,
rtcwake_main,
run_parts_main,
runcon_main,
runlevel_main,
runsv_main,
runsvdir_main,
rx_main,
script_main,
scriptreplay_main,
sed_main,
selinuxenabled_main,
sendmail_main,
seq_main,
sestatus_main,
setarch_main,
setconsole_main,
setenforce_main,
setfiles_main,
setfont_main,
setkeycodes_main,
setlogcons_main,
setsebool_main,
setserial_main,
setsid_main,
chpst_main,
ash_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
showkey_main,
slattach_main,
sleep_main,
smemcap_main,
chpst_main,
sort_main,
split_main,
start_stop_daemon_main,
stat_main,
strings_main,
stty_main,
su_main,
sulogin_main,
sum_main,
sv_main,
svlogd_main,
swap_on_off_main,
swap_on_off_main,
switch_root_main,
sync_main,
sysctl_main,
syslogd_main,
tac_main,
tail_main,
tar_main,
tcpudpsvd_main,
tee_main,
telnet_main,
telnetd_main,
test_main,
tftp_main,
tftpd_main,
time_main,
timeout_main,
top_main,
touch_main,
tr_main,
traceroute_main,
traceroute6_main,
true_main,
tty_main,
ttysize_main,
tunctl_main,
udhcpc_main,
udhcpd_main,
tcpudpsvd_main,
umount_main,
uname_main,
expand_main,
uniq_main,
dos2unix_main,
unlzma_main,
lzop_main,
unxz_main,
unzip_main,
uptime_main,
who_main,
usleep_main,
uudecode_main,
uuencode_main,
vconfig_main,
vi_main,
vlock_main,
volname_main,
wall_main,
watch_main,
watchdog_main,
wc_main,
wget_main,
which_main,
who_main,
whoami_main,
whois_main,
xargs_main,
unxz_main,
unxz_main,
yes_main,
gunzip_main,
zcip_main,
};
#endif

const uint16_t applet_nameofs[] ALIGN2 = {
0x0000,
0x0002,
0x0005,
0x000b,
0x0015,
0x001e,
0x0026,
0x002f,
0x0033,
0x003a,
0x003e,
0x0042,
0x0049,
0x0052,
0x0057,
0x005d,
0x0066,
0x0071,
0x0077,
0x007f,
0x0085,
0x008b,
0x008f,
0x0093,
0x0098,
0x009d,
0x00a4,
0x00aa,
0x00b0,
0x00b6,
0x00bc,
0x00c5,
0x00cb,
0x00d2,
0x00d7,
0x00dc,
0x00e2,
0x00e8,
0x00ec,
0x00f1,
0x00f4,
0x00f9,
0x80ff,
0x0107,
0x010f,
0x0118,
0x011c,
0x0121,
0x0124,
0x0127,
0x0131,
0x013a,
0x0142,
0x0149,
0x0150,
0x0153,
0x015d,
0x0162,
0x016a,
0x0170,
0x0175,
0x0183,
0x018c,
0x018f,
0x0198,
0x01a3,
0x01a8,
0x01ab,
0x01b1,
0x01b7,
0x01bb,
0x01c2,
0x01cc,
0x01d7,
0x01de,
0x01e3,
0x01ee,
0x01f4,
0x01fa,
0x0203,
0x020b,
0x0214,
0x021a,
0x0224,
0x022a,
0x422f,
0x0236,
0x023c,
0x0241,
0x0246,
0x0252,
0x0257,
0x0262,
0x0268,
0x026d,
0x0274,
0x027b,
0x0281,
0x028c,
0x0293,
0x029d,
0x02a3,
0x02a8,
0x02af,
0x02b6,
0x02bb,
0x02c0,
0x02c3,
0x02ca,
0x02cf,
0x02d7,
0x02de,
0x02e7,
0x02ed,
0x02f2,
0x02fa,
0x02fd,
0x0306,
0x030d,
0x0317,
0x031f,
0x0324,
0x032a,
0x032f,
0x0336,
0x033e,
0x0345,
0x034c,
0x034f,
0x0356,
0x035d,
0x0363,
0x0368,
0x036f,
0x0377,
0x037e,
0x0387,
0x0390,
0x0395,
0x039d,
0x03a6,
0x03ac,
0x03b1,
0x03b6,
0x03be,
0x03c6,
0x03ce,
0x03d1,
0x03dd,
0x03e6,
0x03ef,
0x83f6,
0x03fc,
0x0404,
0x040c,
0x0414,
0x0418,
0x041c,
0x0420,
0x0423,
0x042a,
0x0430,
0x0436,
0x043c,
0x0442,
0x0447,
0x044c,
0x0454,
0x045d,
0x0466,
0x046a,
0x0477,
0x047e,
0x0483,
0x0488,
0x0491,
0x0497,
0x049f,
0x04a6,
0x04ad,
0x04b7,
0x04c2,
0x04cc,
0x04d2,
0x04db,
0x04e2,
0x04e9,
0x04f1,
0x04fa,
0x44ff,
0x0505,
0x0510,
0x0517,
0x051a,
0x051d,
0x0524,
0x052f,
0x0532,
0x053a,
0x053f,
0x0546,
0x054c,
0x0555,
0x055a,
0x055d,
0x8564,
0x056b,
0x0571,
0x0577,
0x457d,
0x4582,
0x0588,
0x0596,
0x05a1,
0x05a7,
0x05ac,
0x05b7,
0x05c0,
0x05c9,
0x05d2,
0x05d9,
0x05dc,
0x05e2,
0x05e9,
0x05ed,
0x05f2,
0x05fe,
0x0604,
0x0609,
0x0613,
0x061c,
0x0628,
0x0631,
0x0638,
0x0642,
0x064f,
0x0656,
0x065c,
0x0663,
0x066e,
0x0672,
0x0675,
0x067b,
0x0681,
0x0687,
0x068b,
0x0694,
0x069c,
0x06a6,
0x06ad,
0x06b6,
0x06bc,
0x06c5,
0x06c8,
0x06cf,
0x06dc,
0x06e0,
0x06ef,
0x06f8,
0x06fc,
0x0705,
0x070d,
0x0718,
0x0723,
0x072c,
0x0734,
0x0740,
0x074b,
0x0755,
0x075f,
0x0766,
0x0770,
0x0773,
0x077b,
0x0785,
0x078f,
0x0797,
0x07a0,
0x07a6,
0x07ae,
0x07b8,
0x07bd,
0x07c3,
0x07d5,
0x07da,
0x07e2,
0x87e7,
0x07ea,
0x07f2,
0x07f6,
0x07f9,
0x0800,
0x0808,
0x080f,
0x081b,
0x0820,
0x0827,
0x082f,
0x0833,
0x0838,
0x083c,
0x0843,
0x0847,
0x084e,
0x0856,
0x085b,
0x0860,
0x0866,
0x086b,
0x0873,
0x0877,
0x087d,
0x4880,
0x488b,
0x0897,
0x089c,
0x08a0,
0x08a8,
0x08af,
0x08b6,
0x08bd,
0x08c4,
0x08cb,
0x08d1,
0x08da,
0x08df,
0x08e8,
0x08ef,
0x08f6,
0x08fb,
0x0901,
0x0908,
0x090e,
0x0915,
0x091e,
0x0927,
0x092f,
0x8932,
0x0938,
0x8940,
0x0945,
0x094b,
0x0954,
0x0957,
0x095c,
0x0962,
0x0966,
0x096d,
0x0973,
0x0979,
0x097c,
0x0982,
0x0986,
0x098b,
};

const uint8_t applet_install_loc[] ALIGN1 = {
0x33,
0x32,
0x11,
0x22,
0x13,
0x13,
0x33,
0x22,
0x42,
0x33,
0x33,
0x11,
0x13,
0x13,
0x11,
0x34,
0x34,
0x33,
0x33,
0x13,
0x41,
0x33,
0x31,
0x31,
0x31,
0x11,
0x22,
0x41,
0x33,
0x41,
0x31,
0x13,
0x13,
0x11,
0x33,
0x33,
0x33,
0x43,
0x41,
0x12,
0x23,
0x13,
0x23,
0x33,
0x23,
0x22,
0x41,
0x33,
0x43,
0x41,
0x12,
0x13,
0x21,
0x23,
0x33,
0x13,
0x14,
0x32,
0x22,
0x32,
0x42,
0x22,
0x13,
0x11,
0x11,
0x33,
0x11,
0x11,
0x13,
0x33,
0x32,
0x13,
0x01,
0x41,
0x24,
0x13,
0x23,
0x42,
0x33,
0x11,
0x32,
0x33,
0x13,
0x23,
0x21,
0x34,
0x32,
0x13,
0x22,
0x23,
0x22,
0x31,
0x12,
0x22,
0x11,
0x11,
0x11,
0x42,
0x13,
0x31,
0x33,
0x34,
0x33,
0x33,
0x11,
0x11,
0x32,
0x43,
0x12,
0x31,
0x31,
0x13,
0x23,
0x44,
0x33,
0x34,
0x12,
0x33,
0x33,
0x12,
0x11,
0x22,
0x31,
0x13,
0x23,
0x33,
0x33,
0x11,
0x44,
0x43,
0x21,
0x24,
0x34,
0x44,
0x31,
0x13,
0x33,
0x33,
0x12,
0x33,
0x33,
0x12,
0x13,
0x21,
0x33,
0x24,
0x22,
0x21,
0x32,
0x13,
0x33,
0x43,
0x33,
0x33,
0x33,
0x31,
0x33,
0x31,
0x23,
0x42,
0x13,
0x31,
0x33,
0x33,
0x33,
0x33,
0x31,
0x23,
0x31,
0x33,
0x21,
0x33,
0x33,
0x33,
0x33,
0x33,
0x21,
};

#define MAX_APPLET_NAME_LEN 17
